
document.querySelector(".btn-lampung").addEventListener("click", () => {
  alert("Selamat menjelajahi keindahan Lampung! 🌴✨");
});

document.querySelector(".btn-lampung.green").addEventListener("click", () => {
  alert("Panduan wisata Lampung berhasil diunduh! 📖");
});
